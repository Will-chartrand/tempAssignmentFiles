Contents of submission:
  - README.txt
  - 3000textui2.c
  - 3000.diff
  - willchartrand-comp3000-assign1.txt
